// src/types/auth.ts
export interface LoginRequest {
  email: string;
  password_hash: string;
}
