import { Response } from 'express';
import { AuthRequest } from '../auth/auth.middleware';
export declare const uploadPhoto: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=photo.controller.d.ts.map