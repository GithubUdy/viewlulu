import multer from 'multer';
export declare const upload: multer.Multer;
//# sourceMappingURL=multer.d.ts.map