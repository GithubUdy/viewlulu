import { S3Client } from '@aws-sdk/client-s3';
export declare const s3: S3Client;
export declare const S3_BUCKET: string;
//# sourceMappingURL=s3.d.ts.map