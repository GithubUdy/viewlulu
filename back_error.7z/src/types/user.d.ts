export interface SignupRequest {
    email: string;
    password_hash: string;
    name?: string;
}
//# sourceMappingURL=user.d.ts.map