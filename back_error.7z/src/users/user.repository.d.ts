export declare const findUserByEmail: (email: string) => Promise<any>;
export declare const createUser: ({ email, password_hash, name, }: {
    email: string;
    password_hash: string;
    name: string;
}) => Promise<any>;
//# sourceMappingURL=user.repository.d.ts.map