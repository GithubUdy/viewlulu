import { Pool } from "pg";
export declare const pool: Pool;
//# sourceMappingURL=db.d.ts.map