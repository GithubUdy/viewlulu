export interface LoginRequest {
    email: string;
    password_hash: string;
}
//# sourceMappingURL=auth.d.ts.map