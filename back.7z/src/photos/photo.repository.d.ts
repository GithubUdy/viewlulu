export declare const createPhoto: ({ userId, s3Key, originalName, mimeType, }: {
    userId: number;
    s3Key: string;
    originalName: string;
    mimeType: string;
}) => Promise<any>;
//# sourceMappingURL=photo.repository.d.ts.map