export declare const createCosmetic: ({ userId, s3Key, originalName, mimeType, }: {
    userId: number;
    s3Key: string;
    originalName: string;
    mimeType: string;
}) => Promise<any>;
export declare const getMyCosmetics: (userId: number) => Promise<any[]>;
//# sourceMappingURL=cosmetic.repository.d.ts.map