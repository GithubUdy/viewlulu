declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=test.routes.d.ts.map